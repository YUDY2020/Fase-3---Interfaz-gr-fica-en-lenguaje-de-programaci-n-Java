package interfaz;

import javax.swing.JOptionPane;
import datosEmpleados.Empresa;
import datosEmpleados.Usuario;

public class IniciarSesion extends javax.swing.JFrame
{

    private Empresa empresa;

    public IniciarSesion()
    {
        initComponents();
        setSize(790, 520);
         empresa = new Empresa();
        this.pnlUsuario.setOpaque(false);
        this.pnlUsuario1.setOpaque(false);
        this.pnlUsuario2.setOpaque(false);
        this.jTabbedPane1.setOpaque(false);
        this.jPanel1.setOpaque(false);
        this.jPanel2.setOpaque(false);
        this.jPanel3.setOpaque(false);
       
        this.setLocationRelativeTo(null);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        pnlUsuario = new javax.swing.JPanel();
        btnIngresoE = new javax.swing.JButton();
        txfPassward = new javax.swing.JPasswordField();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txfIdAdministrador = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        pnlUsuario1 = new javax.swing.JPanel();
        btnIngresoA = new javax.swing.JButton();
        txfPassward1 = new javax.swing.JPasswordField();
        jLabel6 = new javax.swing.JLabel();
        txfIdSecretaria = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        pnlUsuario2 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        txfPassward2 = new javax.swing.JPasswordField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txfIdVigilante = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Iniciar sesion");
        setExtendedState(10);
        getContentPane().setLayout(null);

        jTabbedPane1.setOpaque(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        pnlUsuario.setBackground(new java.awt.Color(102, 255, 255));
        pnlUsuario.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btnIngresoE.setText("Ingresar");
        btnIngresoE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresoEActionPerformed(evt);
            }
        });

        txfPassward.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txfPasswardKeyReleased(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("id de usuario");

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Contraseña:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Bienvenido");

        javax.swing.GroupLayout pnlUsuarioLayout = new javax.swing.GroupLayout(pnlUsuario);
        pnlUsuario.setLayout(pnlUsuarioLayout);
        pnlUsuarioLayout.setHorizontalGroup(
            pnlUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUsuarioLayout.createSequentialGroup()
                .addContainerGap(128, Short.MAX_VALUE)
                .addGroup(pnlUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(pnlUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel3)
                        .addComponent(jLabel1)
                        .addComponent(txfPassward)
                        .addComponent(btnIngresoE, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                        .addComponent(txfIdAdministrador)))
                .addGap(96, 96, 96))
        );
        pnlUsuarioLayout.setVerticalGroup(
            pnlUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUsuarioLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txfIdAdministrador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txfPassward, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnIngresoE, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(155, 155, 155)
                .addComponent(pnlUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(155, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addComponent(pnlUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(124, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Administrador", jPanel1);

        pnlUsuario1.setBackground(new java.awt.Color(255, 204, 204));
        pnlUsuario1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btnIngresoA.setText("Ingresar");
        btnIngresoA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresoAActionPerformed(evt);
            }
        });

        txfPassward1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txfPassward1KeyReleased(evt);
            }
        });

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Id de usuario");

        txfIdSecretaria.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txfIdSecretariaKeyReleased(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Bienvenido");

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Contraseña:");

        javax.swing.GroupLayout pnlUsuario1Layout = new javax.swing.GroupLayout(pnlUsuario1);
        pnlUsuario1.setLayout(pnlUsuario1Layout);
        pnlUsuario1Layout.setHorizontalGroup(
            pnlUsuario1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlUsuario1Layout.createSequentialGroup()
                .addContainerGap(128, Short.MAX_VALUE)
                .addGroup(pnlUsuario1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUsuario1Layout.createSequentialGroup()
                        .addGroup(pnlUsuario1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel6)
                            .addComponent(btnIngresoA, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                            .addComponent(txfIdSecretaria)
                            .addComponent(jLabel11)
                            .addComponent(txfPassward1, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(96, 96, 96))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUsuario1Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(140, 140, 140))))
        );
        pnlUsuario1Layout.setVerticalGroup(
            pnlUsuario1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUsuario1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txfIdSecretaria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel11)
                .addGap(3, 3, 3)
                .addComponent(txfPassward1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnIngresoA, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(160, 160, 160)
                .addComponent(pnlUsuario1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(150, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addComponent(pnlUsuario1, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(126, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Secretaria", jPanel2);

        pnlUsuario2.setBackground(new java.awt.Color(102, 102, 255));
        pnlUsuario2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jButton3.setText("Ingresar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        txfPassward2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txfPassward2KeyReleased(evt);
            }
        });

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Id de usuario");

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Contraseña:");

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Bienvenido");

        javax.swing.GroupLayout pnlUsuario2Layout = new javax.swing.GroupLayout(pnlUsuario2);
        pnlUsuario2.setLayout(pnlUsuario2Layout);
        pnlUsuario2Layout.setHorizontalGroup(
            pnlUsuario2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUsuario2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlUsuario2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(txfPassward2)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                    .addComponent(txfIdVigilante))
                .addGap(96, 96, 96))
            .addGroup(pnlUsuario2Layout.createSequentialGroup()
                .addGap(143, 143, 143)
                .addComponent(jLabel10)
                .addContainerGap(142, Short.MAX_VALUE))
        );
        pnlUsuario2Layout.setVerticalGroup(
            pnlUsuario2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUsuario2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txfIdVigilante, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txfPassward2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(160, 160, 160)
                .addComponent(pnlUsuario2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(153, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addComponent(pnlUsuario2, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(126, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Vigilante", jPanel3);

        getContentPane().add(jTabbedPane1);
        jTabbedPane1.setBounds(0, 0, 780, 540);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txfPasswardKeyReleased(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txfPasswardKeyReleased
    {//GEN-HEADEREND:event_txfPasswardKeyReleased
        if (evt.getKeyCode() == 10)
        {
            ingresoSecretaria();
        }
    }//GEN-LAST:event_txfPasswardKeyReleased

    private void btnIngresoEActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnIngresoEActionPerformed
    {//GEN-HEADEREND:event_btnIngresoEActionPerformed
        ingresoAdministrativo();

    }//GEN-LAST:event_btnIngresoEActionPerformed

    private void btnIngresoAActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnIngresoAActionPerformed
    {//GEN-HEADEREND:event_btnIngresoAActionPerformed
        ingresoSecretaria();
    }//GEN-LAST:event_btnIngresoAActionPerformed

    private void txfPassward1KeyReleased(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txfPassward1KeyReleased
    {//GEN-HEADEREND:event_txfPassward1KeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txfPassward1KeyReleased

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButton3ActionPerformed
    {//GEN-HEADEREND:event_jButton3ActionPerformed
        ingresoVigilante();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txfPassward2KeyReleased(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txfPassward2KeyReleased
    {//GEN-HEADEREND:event_txfPassward2KeyReleased
        if (evt.getKeyCode() == 10)
        {
            ingresoAdministrativo();
        }
    }//GEN-LAST:event_txfPassward2KeyReleased

    private void txfIdSecretariaKeyReleased(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txfIdSecretariaKeyReleased
    {//GEN-HEADEREND:event_txfIdSecretariaKeyReleased
        if (evt.getKeyCode() == 10)
        {
            ingresoVigilante();
        }        // TODO add your handling code here:
    }//GEN-LAST:event_txfIdSecretariaKeyReleased
    public void ingresoSecretaria()
    {
        String id = this.txfIdSecretaria.getText();
        String contraseña = this.txfPassward1.getText();
        if (id.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Digite id de usuario");
        } else if (contraseña.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Digite una contraseña");
        } else
        {
            Usuario usuario = this.empresa.inicioSesionSecretaria(id, contraseña);
            if (usuario instanceof Usuario)
            {
                this.empresa.setUsuario(usuario);
                Principal gUIPrincipal = new Principal(this.empresa);
                gUIPrincipal.setLocationRelativeTo(null);
                gUIPrincipal.show();
                this.dispose();
            } else
            {
                JOptionPane.showMessageDialog(this, "El usuario no esta registrado en el sistema");
            }
        }
    }

    private void ingresoVigilante()
    {
        String id = this.txfIdVigilante.getText();
        String contraseña = this.txfPassward2.getText();
        if (id.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Digite id usuario");
        } else if (contraseña.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Digite una contraseña");
        } else
        {
            Usuario usuario = this.empresa.inicioSesionVigilante(id, contraseña);
            if (usuario instanceof Usuario)
            {
                this.empresa.setUsuario(usuario);
                Principal gUIPrincipal = new Principal(this.empresa);
                gUIPrincipal.setLocationRelativeTo(null);
                gUIPrincipal.show();
                this.dispose();
            } else
            {
                JOptionPane.showMessageDialog(this, "El usuario no esta registrado en el sistema");
            }
        }
    }

    private void ingresoAdministrativo()
    {
        String id = this.txfIdAdministrador.getText();
        String contraseña = this.txfPassward.getText();
        if (id.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Digite id usuario");
        } else if (contraseña.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Digite una contraseña");
        } else
        {
            Usuario usuario = this.empresa.inicioSesionAdministrativo(id, contraseña);
            if (usuario instanceof Usuario)
            {
                this.empresa.setUsuario(usuario);
                Principal gUIPrincipal = new Principal(this.empresa);
                gUIPrincipal.setLocationRelativeTo(null);
                gUIPrincipal.show();
                this.dispose();
            } else
            {
                JOptionPane.showMessageDialog(this, "El usuario no esta registrado en el sistema");
            }
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnIngresoA;
    private javax.swing.JButton btnIngresoE;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel pnlUsuario;
    private javax.swing.JPanel pnlUsuario1;
    private javax.swing.JPanel pnlUsuario2;
    private javax.swing.JTextField txfIdAdministrador;
    private javax.swing.JTextField txfIdSecretaria;
    private javax.swing.JTextField txfIdVigilante;
    private javax.swing.JPasswordField txfPassward;
    private javax.swing.JPasswordField txfPassward1;
    private javax.swing.JPasswordField txfPassward2;
    // End of variables declaration//GEN-END:variables

}
