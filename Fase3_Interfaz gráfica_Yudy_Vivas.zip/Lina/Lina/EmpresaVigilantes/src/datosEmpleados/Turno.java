/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datosEmpleados;

import java.util.Date;

/**
 *
 * @author 
 */
public class Turno
{    
    private int id;
    private Secretaria secretaria; 
    private Vigilante vigilante;
    private String lugar;
    private Date horaIgreso;
    private Date horaSalida;
    private Date registro;

    public Turno(int id, Secretaria secretaria, Vigilante vigilante, String lugar, Date registro, Date horaIgreso, Date horaSalida)
    {
        this.id = id;
        this.secretaria = secretaria;
        this.vigilante = vigilante;
        this.lugar = lugar;
        this.registro=registro;
        this.horaIgreso = horaIgreso;
        this.horaSalida = horaSalida;
    }

    
     public Turno( String lugar, Date horaIgreso, Date horaSalida)
    {
        this.lugar = lugar;
        this.horaIgreso = horaIgreso;
        this.horaSalida = horaSalida;
    }

    public Secretaria getSecretaria()
    {
        return secretaria;
    }

    public void setSecretaria(Secretaria secretaria)
    {
        this.secretaria = secretaria;
    }

    public Vigilante getVigilante()
    {
        return vigilante;
    }

    public void setVigilante(Vigilante vigilante)
    {
        this.vigilante = vigilante;
    }

    public String getLugar()
    {
        return lugar;
    }

    public void setLugar(String lugar)
    {
        this.lugar = lugar;
    }

    public Date getHoraIgreso()
    {
        return horaIgreso;
    }

    public void setHoraIgreso(Date horaIgreso)
    {
        this.horaIgreso = horaIgreso;
    }

    public Date getHoraSalida()
    {
        return horaSalida;
    }

    public void setHoraSalida(Date horaSalida)
    {
        this.horaSalida = horaSalida;
    }

    public int getId()
    {
        return id;
    }

    public Date getRegistro()
    {
        return registro;
    }
    
    
    
}
