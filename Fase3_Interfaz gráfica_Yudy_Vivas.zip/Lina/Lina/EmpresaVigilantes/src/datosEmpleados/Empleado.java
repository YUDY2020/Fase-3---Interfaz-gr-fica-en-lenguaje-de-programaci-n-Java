/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datosEmpleados;

/**
 *
 * @author 
 */
public class Empleado extends Usuario
{
    protected int idEmpleado;
    protected String Cedula;
    protected String nombre;
    protected double sueldo;

    public Empleado(String Cedula, String nombre, double sueldo, String Contraseña,String correo)
    {
        super(Contraseña, correo);
        this.Cedula = Cedula;
        this.nombre = nombre;
        this.sueldo = sueldo;
    } 

    public Empleado(int idUsuario,int idEmpleado, String Cedula, String nombre, double sueldo, String Contraseña, String correo)
    {
        super(idUsuario, Contraseña, correo);
        this.idEmpleado = idEmpleado;
        this.Cedula = Cedula;
        this.nombre = nombre;
        this.sueldo = sueldo;
    }

    public int getIdEmpleado()
    {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado)
    {
        this.idEmpleado = idEmpleado;
    }

    

    public String getCedula()
    {
        return Cedula;
    }

    public void setCedula(String Cedula)
    {
        this.Cedula = Cedula;
    }

    public String getNombre()
    {
        return nombre;
    }

    public void setNombre(String nombre)
    {
        this.nombre = nombre;
    }

    public double getSueldo()
    {
        return sueldo;
    }

    public void setSueldo(double sueldo)
    {
        this.sueldo = sueldo;
    }
    
    
}
