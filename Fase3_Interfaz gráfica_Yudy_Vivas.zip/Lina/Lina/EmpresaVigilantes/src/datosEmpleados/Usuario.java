/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datosEmpleados;

/**
 *
 * @author 
 */
public class Usuario
{
   protected int idUsuario;
    protected String Contraseña;
    protected String correo;

    public Usuario(String Contraseña, String correo)
    {
        this.Contraseña = Contraseña;
        this.correo = correo;
    }

    public Usuario(int idUsuario, String Contraseña, String correo)
    {
        this.idUsuario = idUsuario;
        this.Contraseña = Contraseña;
        this.correo = correo;
    }

    public int getIdUsuario()
    {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario)
    {
        this.idUsuario = idUsuario;
    }

    
    public String getContraseña()
    {
        return Contraseña;
    }

    public void setContraseña(String Contraseña)
    {
        this.Contraseña = Contraseña;
    }

    public String getCorreo()
    {
        return correo;
    }

    public void setCorreo(String correo)
    {
        this.correo = correo;
    }
     
}
