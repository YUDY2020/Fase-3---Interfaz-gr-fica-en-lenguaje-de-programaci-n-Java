/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datosEmpleados;

/**
 *
 * @author 
 */
public class Administrador extends Usuario
{
    private int idAdministrador;
    private String Cedula;
    private String nombre;

    public Administrador(String Cedula, String nombre, String Contraseña,String correo)
    {
        super(Contraseña,correo);
        this.Cedula = Cedula;
        this.nombre = nombre;
    }

    public Administrador(int idUsuario, int idAdministrador, String Cedula, String nombre,  String Contraseña, String correo)
    {
        super(idUsuario, Contraseña, correo);
        this.idAdministrador = idAdministrador;
        this.Cedula = Cedula;
        this.nombre = nombre;
    }
    
    public String getCedula()
    {
        return Cedula;
    }

    public void setCedula(String Cedula)
    {
        this.Cedula = Cedula;
    }

    public String getNombre()
    {
        return nombre;
    }

    public void setNombre(String nombre)
    {
        this.nombre = nombre;
    }

    public int getIdAdministrador()
    {
        return idAdministrador;
    }

    public void setIdAdministrador(int idAdministrador)
    {
        this.idAdministrador = idAdministrador;
    }    
}
