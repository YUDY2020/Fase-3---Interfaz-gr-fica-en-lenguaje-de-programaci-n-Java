/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datosEmpleados;

/**
 *
 * @author 
 */
public class Novedad
{
    private int id;
    private  Administrador administrador;
    private String Descripcion;

     public Novedad( Administrador administrador, String Descripcion)
    {
        this.administrador = administrador;
        this.Descripcion = Descripcion;
    }
    public Novedad(int id, Administrador administrador, String Descripcion)
    {
        this.id = id;
        this.administrador = administrador;
        this.Descripcion = Descripcion;
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public Administrador getAdministrador()
    {
        return administrador;
    }

    public void setAdministrador(Administrador administrador)
    {
        this.administrador = administrador;
    }

    public String getDescripcion()
    {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion)
    {
        this.Descripcion = Descripcion;
    }
    
}
