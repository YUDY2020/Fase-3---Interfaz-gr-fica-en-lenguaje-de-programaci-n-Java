/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datosEmpleados;

import datosMysql.EmpleadoSup;
import datosMysql.Admistrador;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author 
 */
public class Empresa
{

    private Usuario usuario;
    private EmpleadoSup empleadoDAO;
    private Admistrador admistradorDAO;

    public Empresa()
    {
        this.empleadoDAO = new EmpleadoSup();
        this.admistradorDAO=new Admistrador();
    }

    

    public ArrayList<Empleado> ConsultarEmpleados()
    {
        ArrayList listaEmpleados = new ArrayList<Empleado>();
        listaEmpleados.addAll(empleadoDAO.consultarListaSecretaria());
        listaEmpleados.addAll(empleadoDAO.consultarListaVigilante());
        return listaEmpleados;
    }
    
    public int RegistrarEmpleado(Empleado empleado)
    {
        int res = 0;
        if (empleado instanceof Secretaria)
        {
            res = this.empleadoDAO.contratarSecretaria(empleado);
        } else if (empleado instanceof Vigilante)
        {
            res = this.empleadoDAO.contratarVigilante(empleado);
        }
        return res;
    }
    

    public int ActualizarEmpleado(Empleado empleado)
    {
        int res = 0;
        if (empleado instanceof Secretaria)
        {
            res = this.empleadoDAO.modificarSecretaria(empleado);
        } else if (empleado instanceof Vigilante)
        {
            res = this.empleadoDAO.modificarVigilante(empleado);
        }
        return res;
    }

    public ArrayList<Turno> consultaDeTurno(String cedula)
    {
        ArrayList<Turno> turnos = this.empleadoDAO.consultarTurnos(cedula);
        return turnos;
    }

   

    public ArrayList<Turno> reportesTurnos(Date  inicio, Date fin)
    {
        inicio.setHours(0);
        inicio.setMinutes(0);
        inicio.setSeconds(0);
        fin.setHours(23);
        fin.setMinutes(59);
        fin.setSeconds(59);
        ArrayList<Turno> turnos = this.empleadoDAO.reportesTurnos(  inicio,  fin);
        return turnos;
    }
    
     public int ingresarNovedad(Novedad novedad)
    {
        return admistradorDAO.ingresarNovedad(novedad);
    }

    public void setUsuario(Usuario usuario)
    {
        this.usuario=usuario;
    }
    public Usuario inicioSesionAdministrativo(String cedula, String contraseña)
    {
         return admistradorDAO.buscarAdministrativo( cedula,  contraseña);
    }

    public Usuario inicioSesionSecretaria(String id, String contraseña)
    {
         return empleadoDAO.buscarSecretaria(id,  contraseña);
    }
    
    public Usuario inicioSesionVigilante(String id, String contraseña)
    {
         return empleadoDAO.buscarVigilante(id,  contraseña);
    }

    public Usuario getUsuario()
    {
        return usuario;
    }
    
}
