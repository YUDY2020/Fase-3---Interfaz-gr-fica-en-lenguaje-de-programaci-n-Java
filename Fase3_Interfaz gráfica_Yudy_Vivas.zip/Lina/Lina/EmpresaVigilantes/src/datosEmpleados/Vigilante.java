/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datosEmpleados;

/**
 *
 * @author 
 */
public class Vigilante extends Empleado
{
     
    public Vigilante(String Cedula, String nombre, double sueldo, String Contraseña,String correo)
    {
        super(Cedula, nombre, sueldo, Contraseña,correo);
    }

   
     public Vigilante(int idUsuario,int idEmpleado,String Cedula, String nombre, double sueldo, String Contraseña,String correo)
    {
        super(idUsuario, idEmpleado, Cedula, nombre, sueldo, Contraseña, correo);
    }

    @Override
    public String toString()
    {
        return this.Cedula+" "+nombre+"- Vigilante "; //To change body of generated methods, choose Tools | Templates.
    }
     
}
