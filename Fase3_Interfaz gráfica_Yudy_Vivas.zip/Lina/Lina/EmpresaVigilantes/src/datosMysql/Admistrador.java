/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datosMysql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import datosEmpleados.Administrador;
import datosEmpleados.Novedad;
import datosEmpleados.Secretaria;
import datosEmpleados.Turno;
import datosEmpleados.Usuario;
import datosEmpleados.Vigilante;

/**
 *
 * @author 
 */
public class Admistrador extends ConsultasMysql<Novedad>
{

    public Admistrador()
    {
        super();
    }

    public int ingresarNovedad(Novedad novedad)
    {
        int res = 0;
        try
        {
            String sql = "CALL ingresar_novedad("
                    + "'" + novedad.getAdministrador().getIdAdministrador() + "', "
                    + "'" + novedad.getDescripcion() + "')";
            res = con.ejecutarSentencia(sql);

        } catch (SQLException ex)
        {
            Logger.getLogger(EmpleadoSup.class.getName()).log(Level.SEVERE, null, ex);
        }
        return res;
    }

    public Usuario buscarAdministrativo(String id, String contraseña)
    {
        Usuario usuario=null;
        String sql = "CALL buscar_administrador('" + id + "','" + contraseña + "')";
        ResultSet res = con.ejecutarConsulta(sql);

        try
        {
            while (res.next())
            {
                usuario = new Administrador(
                        res.getInt("idUsuario"),
                        res.getInt("idAdministrador"),
                        res.getString("cedula"),
                        res.getString("nombre"),
                        res.getString("contrasena"),
                        res.getString("correo")
                );

            }
        } catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Agregar empleado", JOptionPane.ERROR);
        }

        return usuario;
    }
}
