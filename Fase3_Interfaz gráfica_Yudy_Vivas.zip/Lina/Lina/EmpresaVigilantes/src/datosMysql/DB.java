/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datosMysql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Johanes
 */
public abstract class DB
{
    protected String servidor;
    protected String baseDatos;
    protected String usuario;
    protected String contraseña;

    protected Connection conexion;
    protected Statement sentencia;

    public DB()
    {
        this.servidor = "";
        this.baseDatos = "";
        this.usuario = "";
        this.contraseña = "";
    }

    public DB(String servidor, String baseDatos, String usuario, String contraseña)
    {
        this.servidor = servidor;
        this.baseDatos = baseDatos;
        this.usuario = usuario;
        this.contraseña = contraseña;
    }

    public DB(String baseDatos, String usuario, String contraseña)
    {
        this.baseDatos = baseDatos;
        this.contraseña = contraseña;
        this.usuario = usuario;
    }

    public DB(String baseDatos)
    {
        this.baseDatos = baseDatos;
    }

    public String getServidor()
    {
        return servidor;
    }

    public void setServidor(String servidor)
    {
        this.servidor = servidor;
    }

    public String getBaseDatos()
    {
        return baseDatos;
    }

    public void setBaseDatos(String baseDatos)
    {
        this.baseDatos = baseDatos;
    }

    public String getUsuario()
    {
        return usuario;
    }

    public void setUsuario(String usuario)
    {
        this.usuario = usuario;
    }

    public String getContraseña()
    {
        return contraseña;
    }

    public void setContraseña(String contraseña)
    {
        this.contraseña = contraseña;
    }

    public Connection getConexion()
    {
        return conexion;
    }

    public void setConexion(Connection conexion)
    {
        this.conexion = conexion;
    }

    public Statement getSentencia()
    {
        return sentencia;
    }

    public abstract void abrirConexion();

    public void cerrarConexion()
    {
        try
        {
            conexion.close();
        } catch (SQLException ex)
        {
            Logger.getLogger(MYSQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public int ejecutarSentencia(String sql) throws SQLException
    {
        int res = -1;
       
        if (conexion.isClosed() == false)
        {
            sentencia = conexion.createStatement();
            res = sentencia.executeUpdate(sql);
        }
        cerrarConexion();
        return res;
    }

    public ResultSet ejecutarConsulta(String sql)
    {
        ResultSet res = null;
        try
        {
            abrirConexion();
            if (conexion.isClosed() == false)
            {
                sentencia =  conexion.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
                res = sentencia.executeQuery(sql);
            }
        } catch (SQLException ex)
        {
            Logger.getLogger(MYSQL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return res;
    }

    boolean hayConexion()
    {
        return conexion!=null;
    }
}
