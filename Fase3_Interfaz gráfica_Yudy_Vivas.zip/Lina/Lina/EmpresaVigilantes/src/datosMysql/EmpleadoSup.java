/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datosMysql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import datosEmpleados.Administrador;
import datosEmpleados.Empleado;
import datosEmpleados.Secretaria;
import datosEmpleados.Turno;
import datosEmpleados.Usuario;
import datosEmpleados.Vigilante;

public class EmpleadoSup extends ConsultasMysql<Usuario>
{

    public EmpleadoSup()
    {
        super();
    }

    public int contratarSecretaria(Empleado empleado)
    {
        int res = 0;
         con.abrirConexion();
        try
        {
            String sql = "CALL registrar_secretaria("
                    + "'" + empleado.getCedula() + "', "
                    + "'" + empleado.getNombre() + "', "
                    + "'" + empleado.getSueldo() + "', "
                    + "'" + empleado.getCorreo() + "', "
                    + "'" + empleado.getContraseña() + "')";
            res = con.ejecutarSentencia(sql);

        } catch (SQLException ex)
        {
            Logger.getLogger(EmpleadoSup.class.getName()).log(Level.SEVERE, null, ex);
        }
        return res;
    }

    public int contratarVigilante(Empleado empleado)
    {
        int res = 0;
         con.abrirConexion();
        try
        {
            String sql = "CALL registrar_vigilante("
                    + "'" + empleado.getCedula() + "', "
                    + "'" + empleado.getNombre() + "', "
                    + "'" + empleado.getSueldo() + "', "
                    + "'" + empleado.getCorreo() + "', "
                    + "'" + empleado.getContraseña() + "')";
            res = con.ejecutarSentencia(sql);

        } catch (SQLException ex)
        {
            Logger.getLogger(EmpleadoSup.class.getName()).log(Level.SEVERE, null, ex);
        }
        return res;
    }

    public ArrayList<Empleado> consultarListaSecretaria()
    {
        String sql = "CALL consultar_secretaria()";
        return consultarSecretaria(sql);
    }

    private ArrayList<Empleado> consultarSecretaria(String sql)
    {
        ArrayList<Empleado> empleados = new ArrayList<>();
        Empleado empleado;
        con.abrirConexion();
        ResultSet res = con.ejecutarConsulta(sql);

        try
        {
            while (res.next())
            {
                empleado = new Secretaria(
                        res.getInt("idUsuario"),
                        res.getInt("idEmpleado"),
                        res.getString("cedula"),
                        res.getString("nombre"),
                        res.getDouble("Sueldo"),
                        res.getString("contrasena"),
                        res.getString("correo")
                );
                empleados.add(empleado);
            }
        } catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Agregar empleado", JOptionPane.ERROR);
        }
        con.cerrarConexion();
        return empleados;
    }

    public ArrayList<Empleado> consultarListaVigilante()
    {
        String sql = "CALL consultar_vigilante()";
        return consultarVigilante(sql);
    }

    private ArrayList<Empleado> consultarVigilante(String sql)
    {
        ArrayList<Empleado> empleados = new ArrayList<>();
        Empleado empleado;
        con.abrirConexion();
        ResultSet res = con.ejecutarConsulta(sql);

        try
        {
            while (res.next())
            {
                empleado = new Vigilante(
                        res.getInt("idUsuario"),
                        res.getInt("idEmpleado"),
                        res.getString("cedula"),
                        res.getString("nombre"),
                        res.getDouble("Sueldo"),
                        res.getString("contrasena"),
                        res.getString("correo")
                );
                empleados.add(empleado);
            }
        } catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Agregar empleado", JOptionPane.ERROR);
        }
        con.cerrarConexion();
        return empleados;
    }

    public int modificarSecretaria(Empleado empleado)
    {
        int res = 0;   

        con.abrirConexion();        
        try
        {
            String sql = "CALL modificar_secretaria("
                     + "'" + empleado.getIdUsuario() + "', "
                    + "'" + empleado.getIdEmpleado() + "', "
                    + "'" + empleado.getNombre() + "', "
                    + "'" + empleado.getSueldo() + "', "
                    + "'" + empleado.getCorreo() + "', "
                    + "'" + empleado.getContraseña() + "')";
            res = con.ejecutarSentencia(sql);

        } catch (SQLException ex)
        {
            Logger.getLogger(EmpleadoSup.class.getName()).log(Level.SEVERE, null, ex);
        }
        con.cerrarConexion();
        return res;
    }

    public int modificarVigilante(Empleado empleado)
    {
        int res = 0;
         con.abrirConexion();
        try
        {
            String sql = "CALL modificar_vigilante("
                    + "'" + empleado.getIdUsuario() + "', "
                    + "'" + empleado.getIdEmpleado() + "', "
                    + "'" + empleado.getNombre() + "', "
                    + "'" + empleado.getSueldo() + "', "
                    + "'" + empleado.getCorreo() + "', "
                    + "'" + empleado.getContraseña() + "')";
            res = con.ejecutarSentencia(sql);

        } catch (SQLException ex)
        {
            Logger.getLogger(EmpleadoSup.class.getName()).log(Level.SEVERE, null, ex);
        }
        con.cerrarConexion();
        return res;
    }

    public ArrayList<Turno> consultarTurnos(String cedula)
    {
        ArrayList<Turno> turnos = new ArrayList<>();
        Turno turno
;        con.abrirConexion();
         String sql = "CALL consultar_turnos('"+cedula+"')";
        ResultSet res = con.ejecutarConsulta(sql);

        try
        {
            while (res.next())
            {
               Secretaria   secretaria = new Secretaria(
                        res.getInt("secretaria_idUsuario"),
                        res.getInt("secretaria_idEmpleado"),
                        res.getString("secretaria_cedula"),
                        res.getString("secretaria_nombre"),
                        res.getDouble("secretaria_sueldo"),
                        res.getString("secretaria_contrasena"),
                        res.getString("secretaria_correo")
                );
               Vigilante vigilante = new Vigilante(
                        res.getInt("vigilante_idUsuario"),
                        res.getInt("vigilante_idEmpleado"),
                        res.getString("vigilante__cedula"),
                        res.getString("vigilante_nombre"),
                        res.getDouble("vigilante_sueldo"),
                        res.getString("vigilante_contrasena"),
                        res.getString("vigilante_correo")
                );
                turno = new Turno(res.getInt("idturno"),secretaria,vigilante ,res.getString("lugar"), res.getDate("fecha_registro"),res.getDate("hora_ingreso"), res.getDate("hora_salida"));
                turnos.add(turno);

            }
        } catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Agregar empleado", JOptionPane.ERROR);
        }
        con.cerrarConexion();
        return turnos;
    }

    public ArrayList<Turno> reportesTurnos(Date inicio, Date fin)
    {
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        ArrayList<Turno> turnos = new ArrayList<>();
        Turno turno;
        con.abrirConexion();
        String sql = "CALL reporte_turnos('"+sdf.format(inicio)+"','"+sdf.format(fin)+"')";
        ResultSet res = con.ejecutarConsulta(sql);

        try
        {
            while (res.next())
            {                
               Secretaria   secretaria = new Secretaria(
                        res.getInt("secretaria_idUsuario"),
                        res.getInt("secretaria_idEmpleado"),
                        res.getString("secretaria_cedula"),
                        res.getString("secretaria_nombre"),
                        res.getDouble("secretaria_sueldo"),
                        res.getString("secretaria_contrasena"),
                        res.getString("secretaria_correo")
                );
               Vigilante vigilante = new Vigilante(
                        res.getInt("vigilante_idUsuario"),
                        res.getInt("vigilante_idEmpleado"),
                        res.getString("vigilante__cedula"),
                        res.getString("vigilante_nombre"),
                        res.getDouble("vigilante_sueldo"),
                        res.getString("vigilante_contrasena"),
                        res.getString("vigilante_correo")
                );
                turno = new Turno(
                        res.getInt("idturno"),
                        secretaria,vigilante ,
                        res.getString("lugar"), 
                         new Date(res.getTimestamp("fecha_registro").getTime()),
                         new Date(res.getTimestamp("hora_ingreso").getTime()),
                         new Date(res.getTimestamp("hora_salida").getTime())
                        );
                turnos.add(turno);
            }
        } catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Agregar empleado", JOptionPane.ERROR);
        }
        con.cerrarConexion();
        return turnos;
    }
    
    public Usuario buscarSecretaria(String id, String contraseña)
    {
        Usuario usuario=null;
        String sql = "CALL buscar_secretaria('" + id + "','" + contraseña + "')";
         con.abrirConexion();
        ResultSet res = con.ejecutarConsulta(sql);

        try
        {
            while (res.next())
            {
                usuario = new Secretaria(
                         res.getInt("idUsuario"),
                        res.getInt("idEmpleado"),
                        res.getString("cedula"),
                        res.getString("nombre"),
                        res.getDouble("Sueldo"),
                        res.getString("contrasena"),
                        res.getString("correo")
                );

            }
        } catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Agregar empleado", JOptionPane.ERROR);
        }

        return usuario;
    }
    public Usuario buscarVigilante(String id, String contraseña)
    {
        Usuario usuario=null;
        String sql = "CALL buscar_vigilante('" + id + "','" + contraseña + "')";
        ResultSet res = con.ejecutarConsulta(sql);

        try
        {
            while (res.next())
            {
                usuario = new Vigilante(
                        res.getInt("idUsuario"),
                        res.getInt("idEmpleado"),
                        res.getString("cedula"),
                        res.getString("nombre"),
                        res.getDouble("Sueldo"),
                        res.getString("contrasena"),
                        res.getString("correo")
                );

            }
        } catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Agregar empleado", JOptionPane.ERROR);
        }
con.cerrarConexion();
        return usuario;
    }
}
