/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datosMysql;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

/**
 *
 * @author Johanes
 */
public abstract class ConsultasMysql<Tipo> 
{    
    protected DB con;
    protected NumberFormat nf;
    protected SimpleDateFormat sdfSalida;
    protected SimpleDateFormat sdfEntrada;
    protected int numPage;
    protected int numPages;

    public ConsultasMysql() 
    {
        this.nf = NumberFormat.getCurrencyInstance(Locale.getDefault());
        this.sdfSalida = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        this.sdfEntrada = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        con = new MYSQL();
        con.setServidor("localhost");
        con.setBaseDatos("vigilancia");
        con.setUsuario("root");
        con.setContraseña("12345678");
    }
}
