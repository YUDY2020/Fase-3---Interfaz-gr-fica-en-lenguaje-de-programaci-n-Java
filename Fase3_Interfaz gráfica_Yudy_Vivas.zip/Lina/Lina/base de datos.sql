-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: vigilancia
-- ------------------------------------------------------
-- Server version	5.7.28-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrador`
--

DROP TABLE IF EXISTS `administrador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administrador` (
  `idAdministrador` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Usuario_idUsuario` int(10) unsigned NOT NULL,
  `cedula` varchar(12) DEFAULT NULL,
  `nombre` text,
  PRIMARY KEY (`idAdministrador`),
  KEY `Administrador_FKIndex1` (`Usuario_idUsuario`),
  CONSTRAINT `administrador_ibfk_1` FOREIGN KEY (`Usuario_idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrador`
--

LOCK TABLES `administrador` WRITE;
/*!40000 ALTER TABLE `administrador` DISABLE KEYS */;
INSERT INTO `administrador` VALUES (1,1,'54321','Jefe');
/*!40000 ALTER TABLE `administrador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleado`
--

DROP TABLE IF EXISTS `empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleado` (
  `idEmpleado` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Usuario_idUsuario` int(10) unsigned NOT NULL,
  `cedula` varchar(12) DEFAULT NULL,
  `nombre` text,
  `sueldo` double DEFAULT NULL,
  PRIMARY KEY (`idEmpleado`),
  KEY `Empleado_FKIndex1` (`Usuario_idUsuario`),
  CONSTRAINT `empleado_ibfk_1` FOREIGN KEY (`Usuario_idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleado`
--

LOCK TABLES `empleado` WRITE;
/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
INSERT INTO `empleado` VALUES (18,31,'7890','JOHIS FERNANDEZ',1900000),(19,32,'9890','TOBY MERCK',5677777);
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `lista_administrador`
--

DROP TABLE IF EXISTS `lista_administrador`;
/*!50001 DROP VIEW IF EXISTS `lista_administrador`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `lista_administrador` AS SELECT 
 1 AS `idAdministrador`,
 1 AS `idUsuario`,
 1 AS `cedula`,
 1 AS `nombre`,
 1 AS `contrasena`,
 1 AS `correo`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `lista_secretaria`
--

DROP TABLE IF EXISTS `lista_secretaria`;
/*!50001 DROP VIEW IF EXISTS `lista_secretaria`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `lista_secretaria` AS SELECT 
 1 AS `idUsuario`,
 1 AS `contrasena`,
 1 AS `correo`,
 1 AS `idEmpleado`,
 1 AS `cedula`,
 1 AS `nombre`,
 1 AS `sueldo`,
 1 AS `idsecretaria`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `lista_turno`
--

DROP TABLE IF EXISTS `lista_turno`;
/*!50001 DROP VIEW IF EXISTS `lista_turno`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `lista_turno` AS SELECT 
 1 AS `secretaria_idUsuario`,
 1 AS `secretaria_contrasena`,
 1 AS `secretaria_correo`,
 1 AS `secretaria_idEmpleado`,
 1 AS `secretaria_cedula`,
 1 AS `secretaria_nombre`,
 1 AS `secretaria_sueldo`,
 1 AS `idsecretaria`,
 1 AS `vigilante_idEmpleado`,
 1 AS `vigilante_idUsuario`,
 1 AS `vigilante__cedula`,
 1 AS `vigilante_nombre`,
 1 AS `vigilante_sueldo`,
 1 AS `vigilante_contrasena`,
 1 AS `vigilante_correo`,
 1 AS `idVigilante`,
 1 AS `idturno`,
 1 AS `fecha_registro`,
 1 AS `hora_ingreso`,
 1 AS `hora_salida`,
 1 AS `lugar`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `lista_vigilante`
--

DROP TABLE IF EXISTS `lista_vigilante`;
/*!50001 DROP VIEW IF EXISTS `lista_vigilante`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `lista_vigilante` AS SELECT 
 1 AS `idEmpleado`,
 1 AS `idUsuario`,
 1 AS `cedula`,
 1 AS `nombre`,
 1 AS `sueldo`,
 1 AS `contrasena`,
 1 AS `correo`,
 1 AS `idVigilante`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `novedad`
--

DROP TABLE IF EXISTS `novedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `novedad` (
  `idnovedad` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Administrador_idAdministrador` int(10) unsigned NOT NULL,
  `descripcion` text,
  PRIMARY KEY (`idnovedad`),
  KEY `novedad_FKIndex1` (`Administrador_idAdministrador`),
  CONSTRAINT `novedad_ibfk_1` FOREIGN KEY (`Administrador_idAdministrador`) REFERENCES `administrador` (`idAdministrador`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `novedad`
--

LOCK TABLES `novedad` WRITE;
/*!40000 ALTER TABLE `novedad` DISABLE KEYS */;
INSERT INTO `novedad` VALUES (4,1,'VIGILANTE LLEGA BORRACHO');
/*!40000 ALTER TABLE `novedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secretaria`
--

DROP TABLE IF EXISTS `secretaria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `secretaria` (
  `idsecretaria` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Empleado_idEmpleado` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idsecretaria`),
  KEY `secretaria_FKIndex1` (`Empleado_idEmpleado`),
  CONSTRAINT `secretaria_ibfk_1` FOREIGN KEY (`Empleado_idEmpleado`) REFERENCES `empleado` (`idEmpleado`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secretaria`
--

LOCK TABLES `secretaria` WRITE;
/*!40000 ALTER TABLE `secretaria` DISABLE KEYS */;
INSERT INTO `secretaria` VALUES (10,18);
/*!40000 ALTER TABLE `secretaria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `turno`
--

DROP TABLE IF EXISTS `turno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `turno` (
  `idturno` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vigilante_idVigilante` int(10) unsigned NOT NULL,
  `secretaria_idsecretaria` int(10) unsigned NOT NULL,
  `fecha_registro` date DEFAULT NULL,
  `hora_ingreso` datetime DEFAULT NULL,
  `hora_salida` datetime DEFAULT NULL,
  `lugar` text,
  PRIMARY KEY (`idturno`),
  KEY `ticket_FKIndex1` (`vigilante_idVigilante`),
  KEY `ticket_FKIndex2` (`secretaria_idsecretaria`),
  CONSTRAINT `turno_ibfk_1` FOREIGN KEY (`vigilante_idVigilante`) REFERENCES `vigilante` (`idVigilante`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `turno_ibfk_2` FOREIGN KEY (`secretaria_idsecretaria`) REFERENCES `secretaria` (`idsecretaria`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `turno`
--

LOCK TABLES `turno` WRITE;
/*!40000 ALTER TABLE `turno` DISABLE KEYS */;
INSERT INTO `turno` VALUES (1,7,10,'2019-10-20','2019-10-20 07:00:00','2019-10-20 17:00:00','Alkosto');
/*!40000 ALTER TABLE `turno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `idUsuario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contrasena` varchar(15) DEFAULT NULL,
  `correo` text,
  PRIMARY KEY (`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'123','administrador@yahoo.es'),(31,'123','JOHIS@GMAIL.COM'),(32,'123','TOBY@GMAIL.COM');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vigilante`
--

DROP TABLE IF EXISTS `vigilante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vigilante` (
  `idVigilante` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Empleado_idEmpleado` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idVigilante`),
  KEY `tecnico_FKIndex1` (`Empleado_idEmpleado`),
  CONSTRAINT `vigilante_ibfk_1` FOREIGN KEY (`Empleado_idEmpleado`) REFERENCES `empleado` (`idEmpleado`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vigilante`
--

LOCK TABLES `vigilante` WRITE;
/*!40000 ALTER TABLE `vigilante` DISABLE KEYS */;
INSERT INTO `vigilante` VALUES (7,19);
/*!40000 ALTER TABLE `vigilante` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'vigilancia'
--

--
-- Dumping routines for database 'vigilancia'
--
/*!50003 DROP PROCEDURE IF EXISTS `buscar_administrador` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `buscar_administrador`(in id int, in contraseña varchar(50))
BEGIN

SELECT *
FROM `lista_administrador`
WHERE `lista_administrador`.`idUsuario`=id and  `lista_administrador`.`contrasena`=contraseña;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `buscar_secretaria` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `buscar_secretaria`(in id int, in contraseña varchar(50))
BEGIN

SELECT *
FROM `vigilancia`.`lista_secretaria`
WHERE `lista_secretaria`.`idUsuario`=id and  `lista_secretaria`.`contrasena`=contraseña;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `buscar_vigilante` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `buscar_vigilante`(in id int, in contraseña varchar(50))
BEGIN

SELECT `lista_vigilante`.`idEmpleado`,
    `lista_vigilante`.`idUsuario`,
    `lista_vigilante`.`cedula`,
    `lista_vigilante`.`nombre`,
    `lista_vigilante`.`sueldo`,
    `lista_vigilante`.`contrasena`,
    `lista_vigilante`.`correo`,
    `lista_vigilante`.`idVigilante`
FROM `vigilancia`.`lista_vigilante`
WHERE `lista_vigilante`.`idUsuario`=id and  `lista_vigilante`.`contrasena`=contraseña;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `consultar_secretaria` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `consultar_secretaria`()
BEGIN
SELECT
	 lista_secretaria.idUsuario AS idUsuario,
	 lista_secretaria.idEmpleado AS idEmpleado,
     lista_secretaria.`contrasena` AS contrasena,
     lista_secretaria.`correo` AS correo,
     lista_secretaria.`cedula` AS cedula,
     lista_secretaria.`nombre` AS nombre,
     lista_secretaria.`sueldo` AS sueldo
FROM
     `lista_secretaria` ;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `consultar_turnos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `consultar_turnos`(in cedula varchar(12))
BEGIN
SELECT `lista_turno`.`secretaria_idUsuario`,
    `lista_turno`.`secretaria_contrasena`,
    `lista_turno`.`secretaria_correo`,
    `lista_turno`.`secretaria_idEmpleado`,
    `lista_turno`.`secretaria_cedula`,
    `lista_turno`.`secretaria_nombre`,
    `lista_turno`.`secretaria_sueldo`,
    `lista_turno`.`idsecretaria`,
    `lista_turno`.`vigilante_idEmpleado`,
    `lista_turno`.`vigilante_idUsuario`,
    `lista_turno`.`vigilante__cedula`,
    `lista_turno`.`vigilante_nombre`,
    `lista_turno`.`vigilante_sueldo`,
    `lista_turno`.`vigilante_contrasena`,
    `lista_turno`.`vigilante_correo`,
    `lista_turno`.`idVigilante`,
    `lista_turno`.`idturno`,
    `lista_turno`.`fecha_registro`,
    `lista_turno`.`hora_ingreso`,
    `lista_turno`.`hora_salida`,
    `lista_turno`.`lugar`
FROM `vigilancia`.`lista_turno`
WHERE `lista_turno`.`vigilante__cedula`=cedula;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `consultar_vigilante` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `consultar_vigilante`()
BEGIN
SELECT
lista_vigilante.idUsuario AS idUsuario,
	 lista_vigilante.idUsuario AS idEmpleado,
     lista_vigilante.`cedula` AS cedula,
     lista_vigilante.`nombre` AS nombre,
     lista_vigilante.`sueldo` AS sueldo,
     lista_vigilante.`contrasena` AS contrasena,
     lista_vigilante.`correo` AS correo
FROM
     `lista_vigilante` lista_vigilante;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ingresar_novedad` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ingresar_novedad`(
in idAdministrador int, 
in descripcion text)
BEGIN
	INSERT INTO `vigilancia`.`novedad`
	(
	`Administrador_idAdministrador`,
	`descripcion`)
	VALUES
	(
	idAdministrador,
	descripcion);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `modificar_secretaria` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `modificar_secretaria`(
in EntIdUsuario int,
in EntIdEmpleado int, 
in EntNombre varchar(100),  
in EntSueldo double, 
in EntCorreo varchar(100),  
in EntContraseña varchar(20))
BEGIN
	UPDATE `vigilancia`.`usuario`
	SET
	`contrasena` = EntContraseña,
	`correo` = EntCorreo
	WHERE `idUsuario` = EntIdUsuario;
    
    UPDATE `vigilancia`.`empleado`
	SET
	`nombre` =EntNombre,
	`sueldo` = EntSueldo
	WHERE `idEmpleado` = EntIdEmpleado;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `modificar_vigilante` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `modificar_vigilante`(
in EntIdUsuario int,
in EntIdEmpleado int, 
in EntNombre varchar(100),  
in EntSueldo double, 
in EntCorreo varchar(100),  
in EntContraseña varchar(20))
BEGIN
	UPDATE `vigilancia`.`usuario`
	SET
	`contrasena` = EntContraseña,
	`correo` = EntCorreo
	WHERE `idUsuario` = EntIdUsuario;
    
    UPDATE `vigilancia`.`empleado`
	SET
	`nombre` =EntNombre,
	`sueldo` = EntSueldo
	WHERE `idEmpleado` = EntIdEmpleado;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `registrar_secretaria` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `registrar_secretaria`(
in EntCedula varchar(12), 
in EntNombre varchar(100),  
in EntSueldo double, 
in EntCorreo varchar(100),  
in EntContraseña varchar(20))
BEGIN
	declare id integer;
	INSERT INTO `usuario`(`contrasena`,`correo`)VALUES(EntContraseña,EntCorreo); 
	set id=(SELECT idUsuario     FROM usuario     WHERE contrasena =EntContraseña and correo=EntCorreo);
	INSERT INTO `vigilancia`.`empleado`(`Usuario_idUsuario`,`cedula`,`nombre`,`sueldo`)VALUES(id,EntCedula,EntNombre,EntSueldo);
	set id=(SELECT idEmpleado     FROM empleado     WHERE cedula =EntCedula);
    INSERT INTO `secretaria`(`Empleado_idEmpleado`)VALUES(id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `registrar_vigilante` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `registrar_vigilante`(
in EntCedula varchar(12), 
in EntNombre varchar(100),  
in EntSueldo double, 
in EntCorreo varchar(100),  
in EntContraseña varchar(20))
BEGIN
	declare id integer;
	INSERT INTO `usuario`(`contrasena`,`correo`)VALUES(EntContraseña,EntCorreo); 
	set id=(SELECT idUsuario   FROM usuario   WHERE contrasena =EntContraseña and correo=EntCorreo);
	INSERT INTO `empleado`(`Usuario_idUsuario`,`cedula`,`nombre`,`sueldo`)VALUES(id,EntCedula,EntNombre,EntSueldo);
	set id=(SELECT idEmpleado     FROM empleado     WHERE cedula =EntCedula);
    INSERT INTO `vigilante`(`Empleado_idEmpleado`)VALUES(id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reporte_turnos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reporte_turnos`(in inicio datetime, in fin datetime)
BEGIN
SELECT 
	`lista_turno`.`secretaria_idUsuario`,
    `lista_turno`.`secretaria_contrasena`,
    `lista_turno`.`secretaria_correo`,
    `lista_turno`.`secretaria_idEmpleado`,
    `lista_turno`.`secretaria_cedula`,
    `lista_turno`.`secretaria_nombre`,
    `lista_turno`.`secretaria_sueldo`,
    `lista_turno`.`idsecretaria`,
    `lista_turno`.`vigilante_idEmpleado`,
    `lista_turno`.`vigilante_idUsuario`,
    `lista_turno`.`vigilante__cedula`,
    `lista_turno`.`vigilante_nombre`,
    `lista_turno`.`vigilante_sueldo`,
    `lista_turno`.`vigilante_contrasena`,
    `lista_turno`.`vigilante_correo`,
    `lista_turno`.`idVigilante`,
    `lista_turno`.`idturno`,
    `lista_turno`.`fecha_registro`,
    `lista_turno`.`hora_ingreso`,
    `lista_turno`.`hora_salida`,
    `lista_turno`.`lugar`
FROM `vigilancia`.`lista_turno`
WHERE hora_ingreso BETWEEN inicio AND fin;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `lista_administrador`
--

/*!50001 DROP VIEW IF EXISTS `lista_administrador`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `lista_administrador` AS select `administrador`.`idAdministrador` AS `idAdministrador`,`administrador`.`Usuario_idUsuario` AS `idUsuario`,`administrador`.`cedula` AS `cedula`,`administrador`.`nombre` AS `nombre`,`usuario`.`contrasena` AS `contrasena`,`usuario`.`correo` AS `correo` from (`usuario` join `administrador` on((`usuario`.`idUsuario` = `administrador`.`Usuario_idUsuario`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `lista_secretaria`
--

/*!50001 DROP VIEW IF EXISTS `lista_secretaria`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `lista_secretaria` AS select `usuario`.`idUsuario` AS `idUsuario`,`usuario`.`contrasena` AS `contrasena`,`usuario`.`correo` AS `correo`,`empleado`.`idEmpleado` AS `idEmpleado`,`empleado`.`cedula` AS `cedula`,`empleado`.`nombre` AS `nombre`,`empleado`.`sueldo` AS `sueldo`,`secretaria`.`idsecretaria` AS `idsecretaria` from ((`usuario` join `empleado` on((`usuario`.`idUsuario` = `empleado`.`Usuario_idUsuario`))) join `secretaria` on((`empleado`.`idEmpleado` = `secretaria`.`Empleado_idEmpleado`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `lista_turno`
--

/*!50001 DROP VIEW IF EXISTS `lista_turno`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `lista_turno` AS select `lista_secretaria`.`idUsuario` AS `secretaria_idUsuario`,`lista_secretaria`.`contrasena` AS `secretaria_contrasena`,`lista_secretaria`.`correo` AS `secretaria_correo`,`lista_secretaria`.`idEmpleado` AS `secretaria_idEmpleado`,`lista_secretaria`.`cedula` AS `secretaria_cedula`,`lista_secretaria`.`nombre` AS `secretaria_nombre`,`lista_secretaria`.`sueldo` AS `secretaria_sueldo`,`lista_secretaria`.`idsecretaria` AS `idsecretaria`,`lista_vigilante`.`idEmpleado` AS `vigilante_idEmpleado`,`lista_vigilante`.`idUsuario` AS `vigilante_idUsuario`,`lista_vigilante`.`cedula` AS `vigilante__cedula`,`lista_vigilante`.`nombre` AS `vigilante_nombre`,`lista_vigilante`.`sueldo` AS `vigilante_sueldo`,`lista_vigilante`.`contrasena` AS `vigilante_contrasena`,`lista_vigilante`.`correo` AS `vigilante_correo`,`lista_vigilante`.`idVigilante` AS `idVigilante`,`turno`.`idturno` AS `idturno`,`turno`.`fecha_registro` AS `fecha_registro`,`turno`.`hora_ingreso` AS `hora_ingreso`,`turno`.`hora_salida` AS `hora_salida`,`turno`.`lugar` AS `lugar` from ((`lista_secretaria` join `turno` on((`lista_secretaria`.`idsecretaria` = `turno`.`secretaria_idsecretaria`))) join `lista_vigilante` on((`turno`.`vigilante_idVigilante` = `lista_vigilante`.`idVigilante`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `lista_vigilante`
--

/*!50001 DROP VIEW IF EXISTS `lista_vigilante`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `lista_vigilante` AS select `empleado`.`idEmpleado` AS `idEmpleado`,`empleado`.`Usuario_idUsuario` AS `idUsuario`,`empleado`.`cedula` AS `cedula`,`empleado`.`nombre` AS `nombre`,`empleado`.`sueldo` AS `sueldo`,`usuario`.`contrasena` AS `contrasena`,`usuario`.`correo` AS `correo`,`vigilante`.`idVigilante` AS `idVigilante` from ((`usuario` join `empleado` on((`usuario`.`idUsuario` = `empleado`.`Usuario_idUsuario`))) join `vigilante` on((`empleado`.`idEmpleado` = `vigilante`.`Empleado_idEmpleado`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-28 18:34:02
